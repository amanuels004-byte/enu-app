import 'dart:convert';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:just_audio/just_audio.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

const ink = Color(0xFF171329);
const violet = Color(0xFF8D6BDB);
const lilac = Color(0xFFE9DFFF);
const cream = Color(0xFFF8F5FC);

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const EnuApp());
}

class EnuApp extends StatelessWidget {
  const EnuApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'enu',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: cream,
      colorScheme: ColorScheme.fromSeed(seedColor: violet, brightness: Brightness.light),
      appBarTheme: const AppBarTheme(backgroundColor: cream, foregroundColor: ink, elevation: 0),
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
      ),
    ),
    home: const EnuShell(),
  );
}

class Song {
  final String title;
  final String artist;
  final String path;
  const Song({required this.title, required this.artist, required this.path});
  Map<String, dynamic> toJson() => {'title': title, 'artist': artist, 'path': path};
  factory Song.fromJson(Map<String, dynamic> j) => Song(
    title: j['title'] ?? 'Untitled audio',
    artist: j['artist'] ?? 'Local audio',
    path: j['path'] ?? '',
  );
}

class EnuShell extends StatefulWidget {
  const EnuShell({super.key});
  @override
  State<EnuShell> createState() => _EnuShellState();
}

class _EnuShellState extends State<EnuShell> {
  int tab = 0;
  final player = AudioPlayer();
  final tts = FlutterTts();
  final speech = stt.SpeechToText();
  final List<Song> songs = [];
  final List<String> favorites = [];
  final List<String> history = [];
  bool playing = false;
  String? currentPath;
  String currentTitle = 'Choose a worship track';
  String currentArtist = 'Your music, your quiet place';
  String displayName = 'Worshipper';
  bool signedIn = false;
  final chatInput = TextEditingController();
  final List<Map<String, String>> chat = [
    {'role': 'assistant', 'text': 'Peace be with you. I can help you reflect on Scripture, prayer, and worship. What is on your heart today?'}
  ];
  bool listening = false;

  @override
  void initState() {
    super.initState();
    _load();
    player.playerStateStream.listen((s) {
      if (mounted) setState(() => playing = s.playing);
    });
    player.currentIndexStream.listen((_) {});
  }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    final saved = p.getStringList('songs') ?? [];
    final fav = p.getStringList('favorites') ?? [];
    final hist = p.getStringList('history') ?? [];
    final savedChat = p.getStringList('chat') ?? [];
    if (!mounted) return;
    setState(() {
      songs.addAll(saved.map((s) => Song.fromJson(jsonDecode(s))));
      favorites.addAll(fav);
      history.addAll(hist);
      if (savedChat.isNotEmpty) {
        chat
          ..clear()
          ..addAll(savedChat.map((s) => Map<String, String>.from(jsonDecode(s))));
      }
      displayName = p.getString('displayName') ?? 'Worshipper';
      signedIn = p.getBool('signedIn') ?? false;
    });
  }

  Future<void> _save() async {
    final p = await SharedPreferences.getInstance();
    await p.setStringList('songs', songs.map((s) => jsonEncode(s.toJson())).toList());
    await p.setStringList('favorites', favorites);
    await p.setStringList('history', history);
    await p.setStringList('chat', chat.map((m) => jsonEncode(m)).toList());
    await p.setString('displayName', displayName);
    await p.setBool('signedIn', signedIn);
  }

  Future<void> _addAudio() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.audio, withData: false);
    if (result == null || result.files.single.path == null) return;
    final f = result.files.single;
    final song = Song(title: f.name.replaceAll(RegExp(r'\.[^.]+$'), ''), artist: 'From your device', path: f.path!);
    setState(() => songs.insert(0, song));
    await _save();
    if (mounted) _snack('Added to your Enu library. The file stays on your device.');
  }

  Future<void> _play(Song song) async {
    try {
      await player.setFilePath(song.path);
      await player.play();
      setState(() {
        currentPath = song.path;
        currentTitle = song.title;
        currentArtist = song.artist;
        history.remove(song.path);
        history.insert(0, song.path);
        if (history.length > 30) history.removeLast();
      });
      await _save();
    } catch (_) {
      _snack('Could not play this file. Check that it still exists on your device.');
    }
  }

  Future<void> _removeSong(Song song) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Remove track?'),
        content: Text('Remove “${song.title}” from your Enu library? The original audio file will not be deleted.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Keep')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Remove')),
        ],
      ),
    );
    if (confirmed != true) return;
    setState(() {
      songs.removeWhere((s) => s.path == song.path);
      favorites.remove(song.path);
      history.remove(song.path);
      if (currentPath == song.path) {
        currentPath = null;
        currentTitle = 'Choose a worship track';
        currentArtist = 'Your music, your quiet place';
      }
    });
    if (currentPath == null) await player.stop();
    await _save();
  }

  void _toggleFavorite(Song song) async {
    setState(() {
      if (favorites.contains(song.path)) {
        favorites.remove(song.path);
      } else {
        favorites.add(song.path);
      }
    });
    await _save();
  }

  void _snack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  void dispose() {
    player.dispose();
    tts.stop();
    chatInput.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _home(),
      _library(),
      _assistant(),
      _profile(),
    ];
    return Scaffold(
      appBar: AppBar(
        title: Row(children: [
          Container(width: 34, height: 34, decoration: BoxDecoration(color: lilac, borderRadius: BorderRadius.circular(12)),
            child: const Icon(Icons.graphic_eq_rounded, color: ink)),
          const SizedBox(width: 10),
          const Text('enu', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w800, letterSpacing: -1)),
        ]),
        actions: [
          IconButton(tooltip: 'Profile', onPressed: () => setState(() => tab = 3), icon: const Icon(Icons.account_circle_outlined)),
          const SizedBox(width: 4),
        ],
      ),
      body: SafeArea(child: Column(children: [
        Expanded(child: IndexedStack(index: tab, children: pages)),
        if (currentPath != null) _miniPlayer(),
      ])),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.library_music_outlined), selectedIcon: Icon(Icons.library_music), label: 'Library'),
          NavigationDestination(icon: Icon(Icons.auto_awesome_outlined), selectedIcon: Icon(Icons.auto_awesome), label: 'Faith AI'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }

  Widget _home() => ListView(padding: const EdgeInsets.fromLTRB(18, 8, 18, 24), children: [
    Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFF211737), Color(0xFF5B4388)], begin: Alignment.topLeft, end: Alignment.bottomRight),
        borderRadius: BorderRadius.circular(28),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Row(children: [Icon(Icons.wb_twilight, color: Color(0xFFE9DFFF)), SizedBox(width: 8), Text('A MOMENT WITH GOD', style: TextStyle(color: Color(0xFFE9DFFF), letterSpacing: 1.4, fontSize: 11, fontWeight: FontWeight.bold))]),
        const SizedBox(height: 18),
        const Text('Let your heart\nfind its song.', style: TextStyle(color: Colors.white, fontSize: 30, height: 1.12, fontWeight: FontWeight.w800)),
        const SizedBox(height: 12),
        const Text('Make room for worship, stillness, and the Word.', style: TextStyle(color: Color(0xFFE2D9F1), height: 1.4)),
        const SizedBox(height: 20),
        FilledButton.icon(
          style: FilledButton.styleFrom(backgroundColor: const Color(0xFFE9DFFF), foregroundColor: ink),
          onPressed: _addAudio, icon: const Icon(Icons.add), label: const Text('Add music from device'),
        )
      ]),
    ),
    const SizedBox(height: 26),
    _sectionTitle('Your worship library', 'Play audio saved on your phone'),
    const SizedBox(height: 12),
    if (songs.isEmpty)
      _empty(Icons.headphones_rounded, 'Your library starts here', 'Add audio files you own or have permission to use. They can play offline from your device.')
    else
      ...songs.take(4).map(_songTile),
    const SizedBox(height: 24),
    _sectionTitle('A quiet moment', 'Faith, reflection, and prayer'),
    const SizedBox(height: 12),
    InkWell(
      onTap: () => setState(() => tab = 2),
      borderRadius: BorderRadius.circular(22),
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22)),
        child: const Row(children: [
          CircleAvatar(backgroundColor: lilac, child: Icon(Icons.auto_awesome, color: ink)),
          SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Talk with Enu', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            SizedBox(height: 4), Text('Reflect on a Bible passage or begin a prayer.', style: TextStyle(color: Colors.black54)),
          ])),
          Icon(Icons.arrow_forward_ios_rounded, size: 16),
        ]),
      ),
    ),
  ]);

  Widget _sectionTitle(String title, String subtitle) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: ink)),
    const SizedBox(height: 4), Text(subtitle, style: const TextStyle(color: Colors.black54)),
  ]);

  Widget _empty(IconData icon, String title, String body) => Container(
    padding: const EdgeInsets.all(22),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22)),
    child: Column(children: [
      Icon(icon, size: 34, color: violet), const SizedBox(height: 10),
      Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
      const SizedBox(height: 6), Text(body, textAlign: TextAlign.center, style: const TextStyle(color: Colors.black54, height: 1.4)),
    ]),
  );

  Widget _songTile(Song song) => Container(
    margin: const EdgeInsets.only(bottom: 8),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
    child: ListTile(
      leading: Container(width: 46, height: 46, decoration: BoxDecoration(color: lilac, borderRadius: BorderRadius.circular(14)),
        child: const Icon(Icons.music_note_rounded, color: ink)),
      title: Text(song.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
      subtitle: Text(song.artist),
      onTap: () => _play(song),
      trailing: PopupMenuButton<String>(
        tooltip: 'Track options',
        onSelected: (choice) {
          if (choice == 'favorite') _toggleFavorite(song);
          if (choice == 'remove') _removeSong(song);
        },
        itemBuilder: (context) => [
          PopupMenuItem(value: 'favorite', child: Row(children: [
            Icon(favorites.contains(song.path) ? Icons.favorite : Icons.favorite_border, size: 20),
            const SizedBox(width: 10), Text(favorites.contains(song.path) ? 'Remove favorite' : 'Add favorite'),
          ])),
          const PopupMenuItem(value: 'remove', child: Row(children: [
            Icon(Icons.delete_outline, size: 20), SizedBox(width: 10), Text('Remove from library'),
          ])),
        ],
      ),
    ),
  );

  Widget _library() {
    final favSongs = songs.where((s) => favorites.contains(s.path)).toList();
    return ListView(padding: const EdgeInsets.all(18), children: [
      _sectionTitle('Your library', 'Your local tracks, favorites, and listening history'),
      const SizedBox(height: 18),
      FilledButton.icon(onPressed: _addAudio, icon: const Icon(Icons.add), label: const Text('Import audio file')),
      const SizedBox(height: 22),
      const Text('Favorites', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      if (favSongs.isEmpty) const Text('Tap the heart beside a track to save it here.', style: TextStyle(color: Colors.black54))
      else ...favSongs.map(_songTile),
      const SizedBox(height: 20),
      const Text('Recently played', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      if (history.isEmpty) const Text('Tracks you play will appear here.', style: TextStyle(color: Colors.black54))
      else ...history.map((path) {
        final matches = songs.where((s) => s.path == path);
        if (matches.isEmpty) return const SizedBox.shrink();
        return _songTile(matches.first);
      }),
    ]);
  }

  Widget _assistant() => Column(children: [
    Padding(padding: const EdgeInsets.fromLTRB(18, 8, 18, 10), child: Row(children: [
      Container(width: 44, height: 44, decoration: BoxDecoration(color: lilac, borderRadius: BorderRadius.circular(15)), child: const Icon(Icons.auto_awesome, color: ink)),
      const SizedBox(width: 12),
      const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Enu Faith Companion', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
        Text('Scripture • Prayer • Reflection', style: TextStyle(color: Colors.black54, fontSize: 12)),
      ])),
      IconButton(tooltip: 'Clear conversation', onPressed: () async {
        final confirmed = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
          title: const Text('Clear conversation?'),
          content: const Text('This clears the saved Enu chat on this device.'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Clear')),
          ],
        ));
        if (confirmed == true) {
          setState(() {
            chat
              ..clear()
              ..add({'role': 'assistant', 'text': 'Peace be with you. What would you like to reflect on today?'});
          });
          await _save();
        }
      }, icon: const Icon(Icons.delete_sweep_outlined)),
      IconButton(tooltip: 'Read last reply aloud', onPressed: () async {
        final reply = chat.lastWhere((m) => m['role'] == 'assistant', orElse: () => {'text': 'Peace be with you.'})['text']!;
        await tts.speak(reply);
      }, icon: const Icon(Icons.volume_up_outlined)),
    ])),
    const Divider(height: 1),
    Expanded(child: ListView.builder(
      padding: const EdgeInsets.all(16), itemCount: chat.length,
      itemBuilder: (context, i) {
        final mine = chat[i]['role'] == 'user';
        return Align(
          alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
          child: Container(
            constraints: const BoxConstraints(maxWidth: 310),
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: mine ? ink : Colors.white, borderRadius: BorderRadius.circular(18)),
            child: Text(chat[i]['text'] ?? '', style: TextStyle(color: mine ? Colors.white : ink, height: 1.45)),
          ),
        );
      },
    )),
    Padding(padding: const EdgeInsets.fromLTRB(12, 8, 12, 12), child: Row(children: [
      IconButton.filledTonal(
        tooltip: listening ? 'Listening' : 'Speak your question',
        onPressed: _listen,
        style: IconButton.styleFrom(backgroundColor: listening ? violet : null, foregroundColor: listening ? Colors.white : null),
        icon: Icon(listening ? Icons.graphic_eq_rounded : Icons.mic_none_rounded),
      ),
      const SizedBox(width: 8),
      Expanded(child: TextField(controller: chatInput, minLines: 1, maxLines: 4, decoration: const InputDecoration(hintText: 'Ask about faith or prayer…'))),
      const SizedBox(width: 8),
      IconButton.filled(onPressed: _sendChat, icon: const Icon(Icons.send_rounded)),
    ])),
  ]);

  Future<void> _listen() async {
    final available = await speech.initialize(
      onStatus: (s) {}, onError: (e) => _snack('Voice input is unavailable: ${e.errorMsg}'),
    );
    if (!available) {
      _snack('Speech recognition is not available on this device.');
      return;
    }
    setState(() => listening = true);
    await speech.listen(onResult: (result) {
      if (mounted) {
        setState(() {
          chatInput.text = result.recognizedWords;
          if (result.finalResult) listening = false;
        });
      }
    });
    _snack('Listening… speak your question.');
  }

  void _sendChat() {
    final q = chatInput.text.trim();
    if (q.isEmpty) return;
    setState(() {
      chat.add({'role': 'user', 'text': q});
      chatInput.clear();
      chat.add({'role': 'assistant', 'text': _offlineFaithReply(q)});
    });
    _save();
  }

  String _offlineFaithReply(String q) {
    final s = q.toLowerCase();
    if (s.contains('pray') || s.contains('prayer')) {
      return 'You can begin simply and honestly. Thank God for what is good, share what is troubling you, ask for wisdom, and take a quiet moment to listen. Philippians 4:6–7 encourages believers to bring their requests to God with thanksgiving. This is an offline starter response, not a live AI answer.';
    }
    if (s.contains('fear') || s.contains('anxious') || s.contains('worry')) {
      return 'When worry feels heavy, take one moment at a time and consider reading Psalm 23 or Matthew 6:25–34. You do not have to pretend everything is easy. Consider speaking with a trusted pastor or someone you trust, too. This is an offline starter response, not a live AI answer.';
    }
    if (s.contains('jesus') || s.contains('christ')) {
      return 'Christians understand Jesus as central to God’s saving love. You might begin with one of the Gospels—John is a thoughtful place to explore who Jesus is and what he taught. This is an offline starter response, not a live AI answer.';
    }
    return 'Thank you for sharing that. A helpful next step is to read a related Bible passage slowly, notice what it says in context, and speak with a trusted pastor or mature believer if you need guidance. Enu is currently using offline sample replies; connect a secure AI backend to enable live conversation.';
  }

  Widget _profile() => ListView(padding: const EdgeInsets.all(18), children: [
    _sectionTitle('Your Enu account', 'Keep your worship space personal'),
    const SizedBox(height: 18),
    Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22)), child: Column(children: [
      const CircleAvatar(radius: 34, backgroundColor: lilac, child: Icon(Icons.person, color: ink, size: 34)),
      const SizedBox(height: 12),
      Text(displayName, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      const SizedBox(height: 5),
      Text(signedIn ? 'Local demo profile' : 'Guest profile', style: const TextStyle(color: Colors.black54)),
      const SizedBox(height: 16),
      FilledButton(
        onPressed: _editProfile,
        child: Text(signedIn ? 'Edit profile' : 'Create local profile'),
      ),
    ])),
    const SizedBox(height: 18),
    _settingTile(Icons.offline_pin_outlined, 'Offline listening', 'Imported audio plays without internet'),
    _settingTile(Icons.history_rounded, 'Saved history', '${history.length} recently played tracks stored on this device'),
    _settingTile(Icons.lock_outline, 'Privacy note', 'This starter keeps music lists and profile locally. No cloud account is created.'),
    const SizedBox(height: 12),
    const Text('Enu starter v0.1 • Faith content is for reflection and is not a substitute for pastoral care.', style: TextStyle(color: Colors.black54, fontSize: 12, height: 1.5)),
  ]);

  Widget _settingTile(IconData icon, String title, String subtitle) => Container(
    margin: const EdgeInsets.only(bottom: 8),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
    child: ListTile(leading: Icon(icon, color: violet), title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)), subtitle: Text(subtitle)),
  );

  Future<void> _editProfile() async {
    final c = TextEditingController(text: displayName == 'Worshipper' ? '' : displayName);
    final name = await showDialog<String>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Your profile'),
      content: TextField(controller: c, autofocus: true, decoration: const InputDecoration(hintText: 'What should Enu call you?')),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(ctx, c.text.trim()), child: const Text('Save')),
      ],
    ));
    c.dispose();
    if (name == null || name.isEmpty) return;
    setState(() { displayName = name; signedIn = true; });
    await _save();
  }

  Widget _miniPlayer() => Container(
    margin: const EdgeInsets.fromLTRB(12, 0, 12, 8),
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
    decoration: BoxDecoration(color: ink, borderRadius: BorderRadius.circular(18)),
    child: Row(children: [
      const Icon(Icons.music_note_rounded, color: lilac),
      const SizedBox(width: 10),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(currentTitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        Text(currentArtist, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Color(0xFFD4C8E8), fontSize: 12)),
      ])),
      IconButton(color: Colors.white, onPressed: () async {
        if (player.playing) { await player.pause(); } else { await player.play(); }
      }, icon: Icon(playing ? Icons.pause_rounded : Icons.play_arrow_rounded)),
      IconButton(color: Colors.white70, onPressed: () async { await player.stop(); setState(() { currentPath = null; }); }, icon: const Icon(Icons.close_rounded)),
    ]),
  );
}
